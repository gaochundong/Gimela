﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gimela.Rukbat.SVS.ServiceConsole
{
  class Program
  {
    static void Main(string[] args)
    {
    }
  }
}
